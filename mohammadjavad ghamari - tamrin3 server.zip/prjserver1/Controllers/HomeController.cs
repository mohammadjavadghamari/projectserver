﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using prjserver1.Models;

namespace prjserver1.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }
    public IActionResult About()
    {
        return View();
    }
    public IActionResult Contact()
    {
        return View();
    }
    public IActionResult Shop()
    {
        List<Ajnas> ListAjnas = new List<Ajnas>();


        Ajnas obj1 = new Ajnas();
        obj1.Id = 1;
        obj1.Company = "Samsung";
        obj1.Model = "Galaxy S23 Ultra";
        obj1.Release = DateTime.Parse("2023/02/17");
        obj1.Color = "Black";
        obj1.Used = false;//false mean its new and true mean its used
        obj1.Price = 49000000;
        obj1.Mojod = true;
        ListAjnas.Add(obj1);

        Ajnas obj2 = new Ajnas();
        obj2.Id = 2;
        obj2.Company = "Samsung";
        obj2.Model = "Galaxy S22 Ultra";
        obj2.Release = DateTime.Parse("2022/02/25");
        obj2.Color = "white";
        obj2.Used = false;//false mean its new and true mean its used
        obj2.Price = 45000000;
        obj2.Mojod = true;
        ListAjnas.Add(obj2);

        Ajnas obj3 = new Ajnas();
        obj3.Id = 3;
        obj3.Company = "Samsung";
        obj3.Model = "Galaxy A54 5G";
        obj3.Release = DateTime.Parse("2023/03/24");
        obj3.Color = "Green";
        obj3.Used = false;//false mean its new and true mean its used
        obj3.Price = 15000000;
        obj3.Mojod = true;
        ListAjnas.Add(obj3);

        Ajnas obj4 = new Ajnas();
        obj4.Id = 4;
        obj4.Company = "Apple";
        obj4.Model = "Iphone 13 Pro Max";
        obj4.Release = DateTime.Parse("2021/09/14");
        obj4.Color = "Black";
        obj4.Used = false;//false mean its new and true mean its used
        obj4.Price = 90000000;
        obj4.Mojod = true;
        ListAjnas.Add(obj4);

        Ajnas obj5 = new Ajnas();
        obj5.Id = 5;
        obj5.Company = "Apple";
        obj5.Model = "Iphone 13 Pro";
        obj5.Release = DateTime.Parse("2021/09/24");
        obj5.Color = "Gold";
        obj5.Used = false;//false mean its new and true mean its used
        obj5.Price = 70000000;
        obj5.Mojod = true;
        ListAjnas.Add(obj5);

        Ajnas obj6 = new Ajnas();
        obj6.Id = 6;
        obj6.Company = "Xiaomi";
        obj6.Model = "13 Ultra";
        obj6.Release = DateTime.Parse("2023/04/18");
        obj6.Color = "Black";
        obj6.Used = false;//false mean its new and true mean its used
        obj6.Price = 62000000;
        obj6.Mojod = true;
        ListAjnas.Add(obj6);

        Ajnas obj7 = new Ajnas();
        obj7.Id = 7;
        obj7.Company = "Xiaomi";
        obj7.Model = "Poco F5 Pro";
        obj7.Release = DateTime.Parse("2023/12/03");
        obj7.Color = "Black";
        obj7.Used = true;//false mean its new and true mean its used
        obj7.Price = 15000000;
        obj7.Mojod = true;
        ListAjnas.Add(obj7);

        //var query = ListAjnas.Where(x => x.Mojod == true).ToList();
        var p = ListAjnas.Where(x => x.Mojod).ToList();
        var sum= ListAjnas.Sum(x => x.Price);
        ViewBag.Sum = sum;
        return View(p);

    }
    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
