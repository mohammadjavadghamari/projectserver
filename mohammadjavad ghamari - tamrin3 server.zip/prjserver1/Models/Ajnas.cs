using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace prjserver1.Models
{
    public class Ajnas
    {
        [Key]
        public int Id { get; set; }
        [StringLength(100)]
        [Required]
        public string Company { get; set; }
        [StringLength(100)]
        [Required]
        public string Model { get; set; }
        public DateTime? Release { get; set; }
        [Required]
        public Nullable<int> Price { get; set; }
        [StringLength(100)]
        public string? Color { get; set; }
        public bool? Used { get; set; }
        [Required]
        public bool Mojod { get; set; }

        internal static dynamic Sum(Func<object, object> value)
        {
            throw new NotImplementedException();
        }

        internal static object Where(Func<object, object> value)
        {
            throw new NotImplementedException();
        }
    }
}